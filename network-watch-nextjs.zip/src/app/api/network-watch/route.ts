import { NextResponse } from "next/server";
import type { RowDataPacket } from "mysql2";
import { spbuDb } from "@/lib/db-spbu";
import { kpiDb } from "@/lib/db-kpi";
import { getSiteStatus, numberOrNull } from "@/lib/network-status";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface SpbuRow extends RowDataPacket {
  ID: number | null;
  site_sector: string | null;
  siteid: string | null;
  sector: number | null;
  Long: number | null;
  Lat: number | null;
  spbu: string | null;
  Kode: string | null;
  Area: string | null;
  "Kabupaten/Kota": string | null;
  Latitude: number | null;
  Longitude: number | null;
}
interface KpiRow extends RowDataPacket {
  siteid: string;
  Sector: number;
  Date_Hour: Date | string;
  prb: number | null;
  throughput: number | null;
}

export async function GET() {
  try {
    // Explicit columns keep the API response small and avoid leaking unrelated SPBU fields.
    const [spbuRows] = await spbuDb.query<SpbuRow[]>(`
      SELECT ID, site_sector, siteid, sector, \`Long\`, Lat, spbu, Kode, Area,
             \`Kabupaten/Kota\`, Latitude, Longitude
      FROM sitelist_spbu
      WHERE siteid IS NOT NULL AND siteid <> ''
    `);

    // MySQL 8+: pick exactly the newest hourly KPI row per siteid+Sector.
    // If the source is MySQL 5.7, replace this query with a JOIN against MAX(Date_Hour).
    const [kpiRows] = await kpiDb.query<KpiRow[]>(`
      SELECT siteid, Sector, Date_Hour,
             \`DL Resource Block Utilizing Rate (%)\` AS prb,
             \`User Downlink Average Throughput (Mbps)\` AS throughput
      FROM (
        SELECT siteid, Sector, Date_Hour,
               \`DL Resource Block Utilizing Rate (%)\`,
               \`User Downlink Average Throughput (Mbps)\`,
               ROW_NUMBER() OVER (
                 PARTITION BY siteid, Sector
                 ORDER BY Date_Hour DESC
               ) AS rn
        FROM \`4g_kpi_hourly_ftp\`
      ) latest
      WHERE rn = 1
    `);

    const kpiByKey = new Map<string, KpiRow>();
    for (const row of kpiRows) {
      kpiByKey.set(`${String(row.siteid).trim()}::${Number(row.Sector)}`, row);
    }

    const sites = spbuRows.map((row, index) => {
      const siteid = String(row.siteid ?? "").trim();
      const sector = numberOrNull(row.sector);
      const kpi = sector === null ? undefined : kpiByKey.get(`${siteid}::${sector}`);
      const prb = numberOrNull(kpi?.prb);
      const throughput = numberOrNull(kpi?.throughput);
      const siteLat = numberOrNull(row.Lat);
      const siteLng = numberOrNull(row.Long);
      const spbuLat = numberOrNull(row.Latitude);
      const spbuLng = numberOrNull(row.Longitude);
      const status = getSiteStatus(prb, throughput);

      return {
        id: `${siteid || "unknown"}-${sector ?? "x"}-${row.ID ?? index}`,
        siteid,
        sector,
        siteSector: row.site_sector,
        spbu: row.spbu,
        kode: row.Kode,
        area: row.Area,
        kabupatenKota: row["Kabupaten/Kota"],
        site: siteLat !== null && siteLng !== null && Math.abs(siteLat) <= 90 && Math.abs(siteLng) <= 180
          ? { lat: siteLat, lng: siteLng } : null,
        spbuLocation: spbuLat !== null && spbuLng !== null && Math.abs(spbuLat) <= 90 && Math.abs(spbuLng) <= 180
          ? { lat: spbuLat, lng: spbuLng } : null,
        prb,
        throughput,
        status,
        dateHour: kpi?.Date_Hour ? new Date(kpi.Date_Hour).toISOString() : null,
      };
    });

    const counts = {
      total: sites.length,
      green: sites.filter(s => s.status === "GREEN").length,
      yellow: sites.filter(s => s.status === "YELLOW").length,
      red: sites.filter(s => s.status === "RED").length,
      unknown: sites.filter(s => s.status === "UNKNOWN").length,
    };

    return NextResponse.json(
      { success: true, generatedAt: new Date().toISOString(), counts, sites },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (error) {
    console.error("GET /api/network-watch failed:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengambil data SPBU/KPI. Periksa koneksi database dan konfigurasi server." },
      { status: 500 }
    );
  }
}
