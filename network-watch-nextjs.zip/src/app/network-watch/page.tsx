"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { SiteItem, SiteStatus } from "@/components/network-watch/NetworkMap";

const NetworkMap = dynamic(() => import("@/components/network-watch/NetworkMap"), {
  ssr: false, loading: () => <div style={{ padding: 30, color: "#111827" }}>Memuat peta Bali…</div>,
});
interface ApiResponse {
  success: boolean;
  generatedAt?: string;
  error?: string;
  counts: { total: number; green: number; yellow: number; red: number; unknown: number };
  sites: SiteItem[];
}
const statusLabels: Record<SiteStatus, string> = {
  RED: "Critical", YELLOW: "Warning", GREEN: "Healthy", UNKNOWN: "Unknown",
};
export default function NetworkWatchPage() {
  const [data, setData] = useState<ApiResponse | null>(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");
  const [area, setArea] = useState("ALL");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/network-watch", { cache: "no-store" });
      const json = await response.json();
      if (!response.ok || !json.success) throw new Error(json.error || "Gagal mengambil data.");
      setData(json);
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Terjadi kesalahan.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), 60_000);
    return () => window.clearInterval(timer);
  }, [load]);

  const areas = useMemo(() => [...new Set((data?.sites || [])
    .map(s => s.kabupatenKota || s.area).filter((v): v is string => Boolean(v)))].sort(), [data]);

  const filtered = useMemo(() => (data?.sites || []).filter(s => {
    const term = search.trim().toLowerCase();
    const matchesSearch = !term || [s.siteid, s.siteSector, s.spbu, s.kode, s.area, s.kabupatenKota]
      .some(v => v?.toLowerCase().includes(term));
    const matchesStatus = status === "ALL" || s.status === status;
    const matchesArea = area === "ALL" || (s.kabupatenKota || s.area) === area;
    return matchesSearch && matchesStatus && matchesArea;
  }), [data, search, status, area]);

  const counts = {
    total: filtered.length,
    green: filtered.filter(s => s.status === "GREEN").length,
    yellow: filtered.filter(s => s.status === "YELLOW").length,
    red: filtered.filter(s => s.status === "RED").length,
  };

  return (
    <main className="dashboard">
      <div className="map-wrap">
        <NetworkMap sites={filtered} selectedId={selectedId} onSelect={setSelectedId} />
      </div>

      {error && <div className="error-banner">{error} <button onClick={() => void load()}>Coba lagi</button></div>}

      <section className="top-panel">
        <div className="brand-row"><span className="brand-icon">📡</span><div>
          <h1>Network Monitoring - SPBU Bali</h1>
          <div className="subtitle">Live KPI Monitoring · Site-sector 4G · Auto refresh 60 detik</div>
        </div></div>
        <div className="kpi-grid">
          <div className="kpi total"><strong>{loading ? "…" : counts.total}</strong><span>Total Site</span></div>
          <div className="kpi green"><strong>{counts.green}</strong><span>Healthy</span></div>
          <div className="kpi yellow"><strong>{counts.yellow}</strong><span>Warning</span></div>
          <div className="kpi red"><strong>{counts.red}</strong><span>Critical</span></div>
        </div>
        {data?.generatedAt && <div className="subtitle">Data diperbarui: {new Date(data.generatedAt).toLocaleString("id-ID")}</div>}
      </section>

      <section className="filters">
        <div><label htmlFor="search">Cari site / SPBU</label><input id="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Site ID, nama SPBU…" /></div>
        <div><label htmlFor="status">Status KPI</label><select id="status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="ALL">Semua status</option><option value="RED">Red / Critical</option><option value="YELLOW">Yellow / Warning</option><option value="GREEN">Green / Healthy</option><option value="UNKNOWN">Unknown / data kosong</option>
        </select></div>
        <div><label htmlFor="area">Kabupaten / Area</label><select id="area" value={area} onChange={e => setArea(e.target.value)}>
          <option value="ALL">Semua area</option>{areas.map(a => <option key={a} value={a}>{a}</option>)}
        </select></div>
        <div className="refresh-row"><span>{data?.counts.unknown ?? 0} site tanpa KPI lengkap</span><button className="refresh-btn" onClick={() => void load()}>↻ Refresh</button></div>
      </section>

      <section className="legend">
        <div className="legend-title">Status KPI</div>
        <div className="legend-row"><span className="dot green" /> DL PRB di luar kondisi warning</div>
        <div className="legend-row"><span className="dot yellow" /> PRB ≥ 50% & throughput &lt; 5 Mbps</div>
        <div className="legend-row"><span className="dot red" /> PRB ≥ 90% & throughput &lt; 1.5 Mbps</div>
        <div className="legend-row"><span className="dot unknown" /> Data KPI tidak lengkap</div>
        <div className="legend-row"><span style={{ fontSize: 13 }}>●</span> Site BTS</div>
        <div className="legend-row"><span style={{ fontSize: 13 }}>⛽</span> Lokasi SPBU</div>
      </section>

      <section className="site-list">
        <h2>Site terpantau ({filtered.length})</h2>
        {filtered.slice(0, 100).map(s => <div key={s.id} className="site-row" onClick={() => setSelectedId(s.id)}>
          <div className="site-row-top"><span>{s.siteSector || `${s.siteid} / Sector ${s.sector ?? "?"}`}</span><span>{statusLabels[s.status]}</span></div>
          <div className="site-row-sub">PRB {s.prb === null ? "N/A" : `${s.prb}%`} · Throughput {s.throughput === null ? "N/A" : `${s.throughput} Mbps`} · {s.spbu || "SPBU N/A"}</div>
        </div>)}
      </section>
    </main>
  );
}
