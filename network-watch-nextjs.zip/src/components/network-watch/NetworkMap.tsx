"use client";

import { useEffect } from "react";
import L from "leaflet";
import { CircleMarker, MapContainer, Popup, TileLayer, Tooltip, useMap } from "react-leaflet";

export type SiteStatus = "RED" | "YELLOW" | "GREEN" | "UNKNOWN";
export interface SiteItem {
  id: string; siteid: string; sector: number | null; siteSector: string | null;
  spbu: string | null; kode: string | null; area: string | null; kabupatenKota: string | null;
  site: { lat: number; lng: number } | null;
  spbuLocation: { lat: number; lng: number } | null;
  prb: number | null; throughput: number | null; status: SiteStatus; dateHour: string | null;
}
const colors: Record<SiteStatus, string> = {
  RED: "#dc2626", YELLOW: "#f59e0b", GREEN: "#16a34a", UNKNOWN: "#64748b",
};
function fmt(value: number | null, suffix = "") { return value === null ? "N/A" : `${value.toFixed(2)}${suffix}`; }
function FitBali() {
  const map = useMap();
  useEffect(() => { map.setView([-8.4095, 115.1889], 9); }, [map]);
  return null;
}
function makeSpbuIcon() {
  return L.divIcon({
    className: "",
    html: '<div class="spbu-marker" style="width:22px;height:22px">⛽</div>',
    iconSize: [22, 22], iconAnchor: [11, 11],
  });
}
const spbuIcon = typeof window !== "undefined" ? makeSpbuIcon() : undefined;

export default function NetworkMap({ sites, selectedId, onSelect }: {
  sites: SiteItem[]; selectedId: string | null; onSelect: (id: string) => void;
}) {
  return (
    <MapContainer center={[-8.4095, 115.1889]} zoom={9} zoomControl>
      <FitBali />
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {sites.map(site => {
        if (!site.site) return null;
        const color = colors[site.status];
        return (
          <CircleMarker
            key={`site-${site.id}`}
            center={[site.site.lat, site.site.lng]}
            radius={selectedId === site.id ? 9 : 6}
            pathOptions={{ color: "#ffffff", weight: 1.5, fillColor: color, fillOpacity: .95 }}
            eventHandlers={{ click: () => onSelect(site.id) }}
          >
            <Tooltip direction="top">{site.siteSector || `${site.siteid} sector ${site.sector ?? "?"}`}</Tooltip>
            <Popup>
              <div className="popup-title">{site.siteSector || site.siteid}</div>
              <div className="popup-status" style={{ backgroundColor: color }}>{site.status}</div>
              <div className="popup-grid">
                <span>Site ID / sector</span><b>{site.siteid} / {site.sector ?? "N/A"}</b>
                <span>SPBU terdekat</span><b>{site.spbu || "N/A"}</b>
                <span>PRB DL</span><b>{fmt(site.prb, "%")}</b>
                <span>User DL throughput</span><b>{fmt(site.throughput, " Mbps")}</b>
                <span>Area</span><b>{site.kabupatenKota || site.area || "N/A"}</b>
                <span>Waktu KPI</span><b>{site.dateHour ? new Date(site.dateHour).toLocaleString("id-ID") : "N/A"}</b>
              </div>
            </Popup>
          </CircleMarker>
        );
      })}
      {sites.map(site => {
        if (!site.spbuLocation) return null;
        return (
          <CircleMarker
            key={`spbu-${site.id}`}
            center={[site.spbuLocation.lat, site.spbuLocation.lng]}
            radius={4}
            pathOptions={{ color: "#ffffff", weight: 1.5, fillColor: "#111827", fillOpacity: 1 }}
          >
            <Tooltip direction="top">SPBU: {site.spbu || "Nama SPBU tidak tersedia"}</Tooltip>
            <Popup>
              <div className="popup-title">⛽ {site.spbu || "SPBU"}</div>
              <div className="popup-grid">
                <span>Kode SPBU</span><b>{site.kode || "N/A"}</b>
                <span>Site terkait</span><b>{site.siteid} / {site.sector ?? "N/A"}</b>
                <span>Area</span><b>{site.kabupatenKota || site.area || "N/A"}</b>
              </div>
            </Popup>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
